<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="../css/main.css">
<!-- <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" /> -->
<link href="favicon.png" rel="icon" type="image/png" />
</head>
<body>

<h1>My First Heading</h1>

<!--
<script>
/*the only js is to continuously checking the value of the dropdown. for posterity*/
var i = setInterval(function(){$("#trace").val($("input[name=line-style]:checked").val());},100);
</script>
-->

<body>
<!--<input type="text" value="" id="trace"/> -->
<div id="image-dropdown" >
<input checked="checked" type="radio" id="line1" name="line-style" value="1"  /><label for="line1"></label>
<input type="radio" id="line2" name="line-style" value="2"  /><label for="line2"></label>
<input type="radio" id="line3" name="line-style" value="3"  /><label for="line3"></label>
</div>

<?
$spojeni = mysql_connect("sql2.webzdarma.cz","ohrazenice.k8801","mullerj1" );
mysql_select_db("ohrazenice.k8801", $spojeni);
mysql_query("SET NAMES 'utf-8'");

$vysledek = mysql_query("SELECT * FROM t_player ORDER BY id",$spojeni);
/* Konec přímé práce s databází. */

/* Cyklem procházím řádky výsledku a vytahuju z něj hodnoty do nového pole $zaznam*/
while ($zaznam = mysql_fetch_array($vysledek) ):
echo $zaznam["name"] . " ";
echo $zaznam["surname"] . " ";
echo $zaznam["comment"] . "<BR />";
endwhile;

?>

</body>
</html>
