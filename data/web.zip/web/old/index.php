<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
	<meta http-equiv="content-type" content="text/html;charset=windows-1250" />
  <title>-__-=rumbler-galleries.wz.cz=-__-</title>
	<link rel="stylesheet" href="zaklad.css" type="text/css" />
	<meta name="Author" content="rumbler" />
	<meta name="Keywords" content="rumbler, Home Page" />
	<meta name="Description" content="photos, fotky" />
   </head>
      <body bgcolor="#000000" text="#666666" link="#000000" vlink="#000000"><!--WZ-REKLAMA-1.0IZ--><div align="center"><table width="496" border="0"
cellspacing="0" cellpadding="0"><tr><td><a href="http://www.webzdarma.cz/"><img
src="http://i.wz.cz/banner/nudle03.gif" width="28" height="60" 
style="margin: 0; padding: 0; border-width: 0" alt="WebZdarma.cz" /></a></td><td>
<script type="text/javascript">
<!-- /* (c) 2001 AdCycle.com All Rights Reserved.*/ 
var id=494; var jar=new Date();var s=jar.getSeconds();var m=jar.getMinutes();
var flash=s*m+id;var cgi='http://ad.wz.cz';
var p='<iframe src="'+cgi+'/ad.cgi?gid=30&amp;t=_top&amp;id='+flash+'&amp;type=iframe" ';
p+='height="60" width="468" border="0" marginwidth="0" marginheight="0" hspace="0" ';
p+='vspace="0" frameborder="0" scrolling="no">';
p+='<a href="'+cgi+'/click.cgi?gid=30&amp;id='+flash+'" target="_top">';
p+='<img src="'+cgi+'/ad.cgi?gid=30&amp;id='+flash+'" width="468" height="60" ';
p+='border="0" alt="Klikni" /></'+'a></'+'ifra'+'me>'; document.write(p); // -->
</script><noscript><div><a href="http://ad.wz.cz/click.cgi?gid=30&amp;id=494"><img
src="http://ad.wz.cz/ad.cgi?gid=30&amp;id=494"
width="468" height="60" style="margin: 0; padding: 0; border-width: 0" alt="Klikni" /></a></div></noscript>
</td></tr></table></div>
<!--WZ-REKLAMA-1.0IK-->
	  
	 <!--Reklama czechRo-->
<center>
<a href="http://www.czechro.net" target="_blank">
<img border="0" src="http://www.czechro.net/img/bann/czro147x30.gif" 
     width="147" height="30" title="CzechRO.net - Ragnarok Online" alt="" />
</a>

<!--Reklama czechRo-->
<!--
<p align="center">
    <a href="http://validator.w3.org/check?uri=referer">
    <img src="http://www.w3.org/Icons/valid-xhtml10" 
         alt="Valid XHTML 1.0 Transitional" height="31" width="88" /></a>
</p>
<p align="center">
 <a href="http://jigsaw.w3.org/css-validator/">
  <img style="border:0;width:88px;height:31px"
       src="http://jigsaw.w3.org/css-validator/images/vcss" 
       alt="Valid CSS!" />
 </a>
</p> 
-->
	<br /><br />
	
	<a href="http://www.rumbler-galleries.wz.cz/hlavni.php">
        <img src="index.jpg" align="middle" alt="" />
        </a>
	</center> 
<!--	<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"
 WIDTH=100% HEIGHT=100%>
 <PARAM NAME=movie VALUE="prvni.swf"> 
<PARAM NAME=quality VALUE=high> <PARAM NAME=bgcolor VALUE=#000000> 
</OBJECT>-->



<br />

	<span class="text1">Po�et p��stup� od 5.9.2005 - <b><? require "pocitadlo.php"?></b></span>
	<span class="text2">Optimalizov�no pro Internet Explorer (1024x768)</span>
	<span class="text3"> &copy;rumbler</span>
      </body>
</html>
