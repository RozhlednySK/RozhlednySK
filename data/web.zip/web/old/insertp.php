<?
$nick=$HTTP_POST_VARS['nick'];
$komentar = NL2BR(HTMLSpecialChars($HTTP_POST_VARS['message']));
$date = Date("d.m H:i:s"); 
$db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
$db_uzivatel="rumbler";			// uzivatel
$db_heslo="muller";				// heslo pro pristup do databaze
$db_jmeno="rumbler";				// jmeno databaze
$spojeni = MySQL_Connect($db_hostitel, $db_uzivatel, $db_heslo);
$vysledek=MySQL_DB_Query($db_jmeno, "SELECT * FROM guestbook");
$id = MySQL_Num_Rows($vysledek) + 1;
$vysledek=MySQL_DB_Query($db_jmeno, "INSERT INTO guestbook VALUES ('$id','$nick', '$message','$date')");
Header("Location:http://rumbler.xf.cz/guestbook/guestbook.php");
?>
