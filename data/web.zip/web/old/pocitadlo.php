<?
function pristup()
{
	
		$fp = FOpen("pocitadlo.dat", "r+");
		if(!$fp) return;
		$pristupu = fGetS($fp,10)+1 ;
		Rewind($fp);
		FPuts($fp, $pristupu);
		FClose($fp);
		echo $pristupu;
}
pristup();
?>