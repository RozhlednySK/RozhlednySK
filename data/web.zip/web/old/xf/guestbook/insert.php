<?
$message = NL2BR(HTMLSpecialChars($HTTP_POST_VARS['message']));
$nick = HTMLSpecialChars($HTTP_POST_VARS['nick']);
if (($nick == "")||($message == ""))
  {
   Header("Location:http://rumbler.xf.cz/guestbook/guestbook.php?error=1");
   exit('<span class="nick"> Zpr�va nebyla vlo�ena, mus�t vyplnit nick i zpr�vu!');
  } 
$date = Date("d.m | H:i:s"); 
$db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
$db_uzivatel="rumbler";			// uzivatel
$db_heslo="muller";				// heslo pro pristup do databaze
$db_jmeno="rumbler";				// jmeno databaze
$spojeni = MySQL_Connect($db_hostitel, $db_uzivatel, $db_heslo);
$vysledek=MySQL_DB_Query($db_jmeno, "SELECT * FROM guestbook");
$id = MySQL_Num_Rows($vysledek) + 1;
$vysledek=MySQL_DB_Query($db_jmeno, "INSERT INTO guestbook VALUES ('$id','$nick', '$message','$date')");
MySQL_Close($spojeni);
Header("Location:http://rumbler.xf.cz/guestbook/guestbook.php");
?>
