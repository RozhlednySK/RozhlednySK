<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta http-equiv="content-type" content="text/html;charset=windows-1250" />
  <link rel="stylesheet" href="guestbook.css" type="text/css" />
	<meta name="Author" content="rumbler" />
  <title>-__-=Guestbook=-__-</title>
  </head>
  <body>
  <div class="main_sshadow">
  <div class="main_shadow">
  <div class="main">
  <img class="mmain" src="guestbook.gif" alt="" />
   
  <form action="insert.php" method="post">
  <table class="record">
  <tr><td><input type="button" class="refresh" value="Refresh&nbsp;" onclick="location.reload(true);" />
  <input type="submit" class="upload" value="Upload&nbsp;" /></td>
  <td rowspan="2"><textarea class="texta" name="message" rows="3" cols="70"></textarea></td></tr> 
  <tr><td><span class="label">Nick:</span><input type="text"  name="nick" maxlength ="16" class="text" />
  <span class="label">Koment��:</span></td>
  </tr>
  </table>
  </form>
  <br />
  <? if($error == 1) echo '<span class="nick"> Zpr�va nebyla vlo�ena, mus�te vyplnit nick i zpr�vu!'?> 
  <br />
  <div class="ddiv">------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</div>
  <?
  $i = 0;
  if($strana=="") $strana = 1;
  $db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
  $db_uzivatel="rumbler";			// uzivatel
  $db_heslo="muller";				// heslo pro pristup do databaze
  $db_jmeno="rumbler";				// jmeno databaze
  $spojeni = MySQL_Connect($db_hostitel, $db_uzivatel, $db_heslo);
  $vysledek=MySQL_DB_Query($db_jmeno, "SELECT * FROM guestbook ORDER BY id DESC");
  $pocet = MySQL_Num_Rows($vysledek);
  $stran = $pocet / 5;
  while (($zaznam = MySQL_Fetch_Array($vysledek)) && ( $zaznam["id"] >= ($pocet - ($strana * 5) + 1)))
  
  {
  if ($zaznam["id"] <= (($pocet - ($strana * 5 ) + 5)))
   {
   echo '<table class="record"><tr><td class="message"><span class="date">' . $zaznam["datum"] . "</span> " .   
        '<span class="nick">&nbsp;' . $zaznam["jmeno"] . " :</span><br /><br />" .
        '<span class="message">' . $zaznam["zprava"]. "</span></td></tr></table>";
   echo '<div class="ddiv">---------------------------------------------------'.
   '---------------------------------------------------------------------------'.
   '---------------------------------------------------------------------------'.
   '---------------------------------------</div>';

  }
  }
   for($i = 1; $i<=$stran + 1;$i++){
	
	if($strana== $i){  echo $i. '&nbsp;'; }
 	else
	  {
		echo '<a href="guestbook.php?strana=' . $i . '">' . $i . '</a>&nbsp;';
	  }
       
   };   
  MySQL_Close($spojeni);
?>
  <br />
  </div>
  </div>
  </div>
  </body>
</html>
