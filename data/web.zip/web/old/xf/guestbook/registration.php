<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta http-equiv="content-type" content="text/html;charset=windows-1250" />
  <link rel="stylesheet" href="registration.css" type="text/css" />
	<meta name="Author" content="rumbler" />
	<meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <title>-__-=Registration=-__-</title>
  </head>
  <body>
  
  <div class="main"> 
  <img class="main" src="guestbook.gif" />
  <h1>Registration</h1>
  <br /><br /><br /><br /><br />
  <form action="insertr.php" method="post">
  <div class="rest"><span class="label">Nick:</span> <input type="text"  name="nick" maxlength ="16" class="nick" />
  <span class="label">Password:</span> 
  <input type="password" name="password" maxlength ="8" class="password" />
  <input type="submit" class="upload" value="Upload&nbsp;" /></div>
  </form>
  <br /><br />
  
  </div>
  </body>
</html>
