<?
$password = NL2BR(HTMLSpecialChars($HTTP_POST_VARS['password']));
$nick = NL2BR(TMLSpecialChars($HTTP_POST_VARS['nick']));
$db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
$db_uzivatel="rumbler";			// uzivatel
$db_heslo="muller";				// heslo pro pristup do databaze
$db_jmeno="rumbler";				// jmeno databaze
$spojeni = MySQL_Connect($db_hostitel, $db_uzivatel, $db_heslo);
$test=MySQL_DB_Query($db_jmeno, "SELECT nick FROM guestbook WHERE nick LIKE '$nick'");
if (MySQL_Num_Rows($test)==1){
  Header("Location:http://rumbler.xf.cz/guestbook/guestbook.php?nick=$nick"); !!!!!!!asdsflsd;kfajlsd;j
}
$vysledek=MySQL_DB_Query($db_jmeno, "SELECT nick FROM guestbook WHERE");
$id = MySQL_Num_Rows($vysledek) + 1;
$vysledek=MySQL_DB_Query($db_jmeno, "INSERT INTO users VALUES ('$id','$nick', '$password')");
MySQL_Close($spojeni);
Header("Location:http://rumbler.xf.cz/guestbook/guestbook.php?nick=$nick");
?>
