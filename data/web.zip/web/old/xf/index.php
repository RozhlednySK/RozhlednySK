<HTML>
<HEAD>
<TITLE>-__-=rumbler.xf.cz=-__-</TITLE>
<link rel="stylesheet" href="zaklad.css" type="text/css">
<META NAME="Author" CONTENT="rumbler">
<META NAME="Keywords" CONTENT="rumbler, Home Page">
<META NAME="Description" CONTENT="photos, fun, fotky, z�bava">
</HEAD><BODY bgcolor="#000000" text=#666666><!--WZ-REKLAMA-1.0--><!--WZ-REKLAMA-1.0--><!--WZ-REKLAMA-1.0IZ--><div align="center"><table width="496" border="0"
cellspacing="0" cellpadding="0"><tr><td><a href="http://www.webzdarma.cz/"><img
src="http://i.wz.cz/banner/nudle03.gif" width="28" height="60" 
style="margin: 0; padding: 0; border-width: 0" alt="WebZdarma.cz" /></a></td><td>
<script type="text/javascript">
<!-- /* (c) 2001 AdCycle.com All Rights Reserved.*/ 
var id=494; var jar=new Date();var s=jar.getSeconds();var m=jar.getMinutes();
var flash=s*m+id;var cgi='http://ad.wz.cz';
var p='<iframe src="'+cgi+'/ad.cgi?gid=30&amp;t=_top&amp;id='+flash+'&amp;type=iframe" ';
p+='height="60" width="468" border="0" marginwidth="0" marginheight="0" hspace="0" ';
p+='vspace="0" frameborder="0" scrolling="no">';
p+='<a href="'+cgi+'/click.cgi?manager=adcycle.com&amp;gid=30&amp;id='+flash+'" target="_top">';
p+='<img src="'+cgi+'/ad.cgi?gid=30&amp;id='+flash+'" width="468" height="60" ';
p+='border="0" alt="Klikni" /></'+'a></'+'ifra'+'me>'; document.write(p); // -->
</script><noscript><div><a href="http://ad.wz.cz/click.cgi?manager=adcycle.com&amp;gid=30&amp;id=494"><img
src="http://ad.wz.cz/ad.cgi?gid=30&amp;id=494"
width="468" height="60" style="margin: 0; padding: 0; border-width: 0" alt="Klikni" /></a></div></noscript>
</td></tr></table></div>
<!--WZ-REKLAMA-1.0IK-->
<? 
for($i=1;$i<=10;$i++) echo "<br>"; 
?>
<A HREF=http://www.rumbler.xf.cz/main.php><h1>Enter</h1></A> <!-- text used in the movie-->
</OBJECT>
<? require "pocitadlo.php"?>
</BODY>
</HTML>
