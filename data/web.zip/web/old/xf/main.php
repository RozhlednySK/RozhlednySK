	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml" >
  <head>
    <title>-__-=rumbler.xf.cz=-__-</title>
    <link rel="stylesheet" href="main.css" type="text/css" />
    <meta http-equiv="Content-Type" content="text/html; charset=Windows-1250" />
    <meta name="Author" content="Jan M�ller" />
  </head>  
  <body>
  <ul>
  <li>&nbsp;<a href="http://rumbler.xf.cz/pokec.html">&nbsp;Pokec informatik�</a></li>
  <li>&nbsp;<a href="http://rumbler.xf.cz/guestbook/guestbook.php">&nbsp;Guestbook</a></li>
  </ul>
  </body>
</HTML>
