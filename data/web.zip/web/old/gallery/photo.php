<?
$web = "http://" . $SERVER_NAME;
$fotky = SubStr(DirName($PATH_TRANSLATED), StrRPos(DirName($PATH_TRANSLATED),"/") + 1,
         StrLen(DirName($PATH_TRANSLATED))-StrRPos(DirName($PATH_TRANSLATED),"/") );  //adresar s fotkama
$db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
$db_uzivatel="rumbler";			// uzivatel
$db_heslo="muller";				// heslo pro pristup do databaze
$db_jmeno="rumbler";				// jmeno databaze
$kom = $fotky . $fotka;  //nazev fotky v db 
$spojeni = MySQL_Connect($db_hostitel,$db_uzivatel,$db_heslo);
$vysledek = MySQL_DB_Query($db_jmeno, "SELECT * FROM comments WHERE (adresar LIKE '$fotky') AND (fotka LIKE '$kom') ORDER BY id"); 
$dir = opendir("mini");
while (($file = readdir($dir)) != false)
  {
//  echo "filename: " . $file . "<br />";
  $i += 1;
  }closedir($dir);
$max = $i - 2;   //pocet fotek
?>



<HTML>

<HEAD>
<TITLE>_-=<? echo $fotky ?>=-_</TITLE>
<link rel="stylesheet" href="hlavni.css" type="text/css">
<META http-equiv="Content-Type" content="text/html; charset=Windows-1250">
<META name="robots" content="nofolow">
</HEAD>
<BODY bgcolor = black link="white" vlink="gray">
<font color = "white">
<Center><a href="<? echo $PHP_SELF;?>?fotka=<? if((int)$fotka>1) echo  $nfotka = $fotka - 1; else echo $fotka ?>">
<? if($fotka!=1) echo "<-" ?> </a>
<?echo $fotka?>/<? echo $max ?>
<a href="<? echo $PHP_SELF;?>?fotka=<? if((int)$fotka<$max) echo  $nfotka = $fotka + 1; else echo $fotka  ?>">
<? if($fotka!=$max) echo "->" ?></a>
</Center>
<br>
<CENTER><IMG SRC="<?echo $web ?>/<?echo $fotky ?>/<?echo $fotky ?><?echo $fotka ?>.JPG"  BORDER=0 ALT=""></CENTER>
<br>
<? while($zaznam = MySQL_Fetch_Array($vysledek)) {	
	echo "<span class=nick>" . $zaznam['nick'] . ":</span> ";
	echo "<span class=comment>" .$zaznam['komentar']. "</span><br>";
	echo "<Center>---------------------------------------------------------------------------------".
	"-------------------------------------------------</Center>" . "<br>";
   };?>

<CENTER><H1>P�id�n� popisk� k fotk�m</H1>
<FORM ACTION="insertp.php?cislo=<? echo $fotka;?>" METHOD=POST>
<TABLE bgcolor="#999999" WIDTH=800 border = 5 bordercolor="black" frame="box" rules="none">
<TR>
<TD><span class=form>Nick: </span> <INPUT CLASS="pole" TYPE="text"  NAME="nick" size="12"></td>
<TD><span class=form>Koment��: </span><TEXTAREA  CLASS="texta" NAME="komentar" ROWS=1 COLS=70></TEXTAREA></td>
<td><INPUT TYPE=SUBMIT CLASS="tlacitko" VALUE="Upload"></td>
 </TR>
</TABLE>

</FORM>
<br><br>
<CENTER>
<a href="<? echo $PHP_SELF;?>?fotka=<? if((int)$fotka>1) echo  $nfotka = $fotka - 1; else echo $fotka  ?>">
<? if($fotka!=1) echo "<-" ?></a>
<?echo $fotka?>/<? echo $max ?>
<a href="<? echo $PHP_SELF;?>?fotka=<? if((int)$fotka<$max) echo  $nfotka = $fotka + 1; else echo $fotka  ?>">
<? if($fotka!=$max) echo "->" ?></a>
</Center>
</BODY>
</HTML>
