<HTML>
<Head><Title>...</Title></Head>
<Body>
<?
$nick=$HTTP_POST_VARS['nick'];
$adresar = SubStr(DirName($PATH_TRANSLATED), StrRPos(DirName($PATH_TRANSLATED),"/") + 1,
         StrLen(DirName($PATH_TRANSLATED))-StrRPos(DirName($PATH_TRANSLATED),"/") );
$fotka = $adresar . $cislo;
$komentar = NL2BR(HTMLSpecialChars($HTTP_POST_VARS['komentar']));
$db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
$db_uzivatel="rumbler";			// uzivatel
$db_heslo="muller";				// heslo pro pristup do databaze
$db_jmeno="rumbler";				// jmeno databaze
$spojeni = MySQL_Connect($db_hostitel, $db_uzivatel, $db_heslo);
$vysledek=MySQL_DB_Query($db_jmeno, "SELECT * FROM comments");
$id = MySQL_Num_Rows($vysledek) + 1;
//echo $vysledek=MySQL_DB_Query($db_jmeno, "SELECT COUNT(*) FROM comments");
$vysledek=MySQL_DB_Query($db_jmeno, "INSERT INTO comments VALUES ('$id','$adresar', '$fotka', '$komentar','$nick','$cas')");
MySQL_Close($spojeni); 
echo "<br>Koment�� p�id�n k fotce cislo " . $cislo . " v adresari ". $adresar . ".<br>" ;
echo "fotka - " .$fotka.".JPG";
echo "<BR> Hotovo \n";
?>
<FORM ACTION="photo.php?fotka=<?echo $cislo;?>" METHOD=POST>
<P><CENTER><INPUT TYPE=SUBMIT VALUE="Back">
</FORM>
</Body>
</Html>