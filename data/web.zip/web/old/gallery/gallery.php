<?
$web = "http://" . $SERVER_NAME;
$fotky = SubStr(DirName($PATH_TRANSLATED), StrRPos(DirName($PATH_TRANSLATED),"/") + 1,
StrLen(DirName($PATH_TRANSLATED))-StrRPos(DirName($PATH_TRANSLATED),"/") );
$db_hostitel="mysql.webzdarma.cz";	// hostitel na kterem db bezi
$db_uzivatel="rumbler";			// uzivatel
$db_heslo="muller";				// heslo pro pristup do databaze
$db_jmeno="rumbler";				// jmeno databaze
$spojeni = MySQL_Connect($db_hostitel,$db_uzivatel,$db_heslo);
$kom = $fotky . $fotka;  //nazev fotky v db 
$dir = opendir("mini");
while (($file = readdir($dir)) != false)
  {
//  echo "filename: " . $file . "<br />";
  $i += 1;
  }closedir($dir);

$max = $i - 2;
$stran = $max / 30;
if ($strana =="") $strana = 1; 
?>



<HTML>

<HEAD>
<TITLE>_-=<?echo $fotky?>=-_</TITLE>
<link rel="stylesheet" href="hlavni.css" type="text/css">
<META http-equiv="Content-Type" content="text/html; charset=Windows-1250">
</HEAD>
<BODY bgcolor = black link="white" vlink="gray">
<CENTER>
  
   <? for($i = 1; $i<=$stran + 1;$i++){
	
	if($strana== $i){  echo $i. ' &nbsp '; }
 	else
	  {
		echo '<a href="gallery.php?strana=' . $i . '" TARGET="_self">' . $i . '</a> &nbsp ';
	  }
       
   }; ?>

<TABLE bgcolor="#000000" WIDTH=800 border = 5 bordercolor="black" frame="box" rules="none">
<TR>
<? 
$pom = (($strana - 1) * 30) + 1;
if (($strana * 30) >= $max) $pom1 = $max;
else $pom1 = (($strana - 1) * 30) + 30;
for($i = $pom; $i<=$pom1;$i++):?> 

	<TD align="center">
     <a href="photo.php?fotka=<?echo $i ?>" TARGET="_blank"><IMG SRC="<?echo $web ?>/<?echo $fotky ?>/mini/<?echo $fotky ?><?echo $i ?>.JPG"  BORDER=0 ALT=""></a>&nbsp;
	 <?
	 $nazev= $fotky.$i;
	 $vysledek = MySQL_DB_Query($db_jmeno, "SELECT * FROM comments WHERE fotka LIKE '$nazev'");
	 echo "<span class=comment1>Po�et koment���: </span>" . MySQL_Num_Rows($vysledek); 
	 ?>
 <? if(($i % 5) == 0):?> <TR> <?endif;?>
 <? endfor ?>
	</TR>   
</TABLE>
<? for($i = 1; $i<=$stran + 1;$i++){
	
	if($strana== $i){  echo $i. ' &nbsp '; }
 	else
	  {
		echo '<a href="gallery.php?strana=' . $i . '" TARGET="_self">' . $i . '</a> &nbsp ';
	  }
       
   }; ?>
</CENTER>
</BODY>
</HTML>