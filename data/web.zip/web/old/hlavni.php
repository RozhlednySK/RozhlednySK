	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml" >
  <head>
    <title>-__-=rumbler-galleries.wz.cz=-__-</title>
    <link rel="stylesheet" href="hlavni.css" type="text/css" />
    <meta http-equiv="Content-Type" content="text/html; charset=Windows-1250" />
    <meta name="Author" content="Jan M�ller" />
  </head>
  <body link="white" vlink="white" alink="white">
	<table align="center" frame = "void" border = "0" style="padding: 5px 5px 5px 5px;"><tr>
	<table align="center"  width = "800" frame = "box" rules="none" border= "5" bordercolor= "black" >
 	<td align="center"  bordercolor=#666666>     	
	<table align = "center" width = 800 frame = "box" rules = "none" border = 5 bordercolor = "black">
   	<tr bordercolor = #666666 >
			<td  bordercolor = #666666>
			<center><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"  WIDTH=600 HEIGHT=40>
			<param name=movie value="moje.swf"> <param name=quality value=high> <param name=bgcolor value=#000000>
			</object></center>
			<td>
	</tr>
	</tr>
	
        </table>
	</td>
    </table>
	<!--
	<? for($i=1; $i<=1;$i++):?>
	<? endfor ?>
	style="position:relative;top=-10px" -->
	<br /><br />
	<table align = "center" width = 800 height = 600 border = "5"  bgcolor="black" bordercolor="b" style="margin-left:auto;margin-right:auto;border-style:double;"">
   	<tr bordercolor = #666666 >
	<td  bordercolor = #666666 align = "center" valign = "top">
	<!--		<?if($co==""):?>	
				<Br><Br><Br><Br><Br><Br><Br><Br>
				<div class=stin>Zat�m toho tady moc nen�, ale pracuju na tom...</stin>			
				<div class=abc>Zat�m toho tady moc nen�, ale pracuju na tom...</abc> 
				<?endif?>
				<BR>  -->
			<?if($co==""):?>
			<Br>
				<div class="stin">Galleries</div>			
				<div class="abc">Galleries</div>
				<div class="stin">~~~~~~~~~~~~~~</div>			
				<div class="abc">~~~~~~~~~~~~~~</div> 
				 
								
			<br>
			<table width = "700" height = "150" align = "center" border="1" frame = "below" bordercolor = #888888>
			<tr bordercolor="black" >
			
				<td class="bezramecku"><p class="vtipy"><a href ="http://www.rumbler.wz.cz/silvestr/galery.html" target = _blank>Silvestr 2005</a> - jak to tam vypadalo</p><br>&nbsp</td>
				<td class="obrazek"><a class="obrazek" href ="http://www.rumbler.wz.cz/silvestr/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler.wz.cz/silvestr/mini/silvestr-16.jpg" ></TD>
								</a>
			</tr>
			</table>
				<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://www.rumbler.wz.cz/umartina/gallery.php" target = _blank>U Martina na chat�</a> - pr�zdniny 2005 </vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://www.rumbler.wz.cz/umartina/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler.wz.cz/umartina/mini/umartina27.jpg" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://www.rumbler-galleries.wz.cz/brnosession/gallery.php" target = _blank>Brno session</a> - aneb posezen� v Brn� </vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://www.rumbler-galleries.wz.cz/brnosession/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler-galleries.wz.cz/brnosession/mini/brnosession1.jpg" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://www.rumbler-galleries.wz.cz/hory2006/gallery.php" target = _blank>Hory 2006</a> - Jansk� L�zn�, chata Alenka</vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://www.rumbler-galleries.wz.cz/hory2006/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler-galleries.wz.cz/hory2006/mini/hory200661.JPG" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://www.rumbler-galleries.wz.cz/20narozky/gallery.php" target = _blank>M� 20. narozeniny</a> - na p��n� odstran�ny kompromituj�c� fotografie ;)</vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://www.rumbler-galleries.wz.cz/20narozky/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler-galleries.wz.cz/20narozky/mini/20narozky35.jpg" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://www.rumbler-galleries.wz.cz/Milan20/gallery.php" target = _blank>Milanovi 20. narozeniny</a> - restaurace ��ba</vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://www.rumbler-galleries.wz.cz/Milan20/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler-galleries.wz.cz/Milan20/mini/Milan201.JPG" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://www.rumbler-galleries.wz.cz/Janca20/gallery.php" target = _blank>Jan�iny 20. narozeniny</a> - u Martina na chat�</vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://www.rumbler-galleries.wz.cz/Janca20/gallery.php" target = _blank>
				<img class=obrazek src="http://www.rumbler-galleries.wz.cz/Janca20/mini/Janca2045.JPG" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a href ="http://rumbler.xf.cz/Silvestr2006/gallery.php" target = _blank>Silvestr 2006</a> - no comment</vtipy><Br>&nbsp</TD>
				<TD class=obrazek><a class=obrazek href ="http://rumbler.xf.cz/Silvestr2006/gallery.php" target = _blank>
				<img class=obrazek src="http://rumbler.xf.cz/Silvestr2006/mini/Silvestr200689.jpg" ></TD>
								</a>
			</TR>
			</TABLE>
			<TABLE width = 700 height = 150 align = "center" border=1 frame = "below" bordercolor = #888888>
			<TR bordercolor=black >
			
				<TD class=bezramecku><p class=vtipy><a class=mobil href ="http://www.rumbler-galleries.wz.cz/mobil/gallery.php" target = _blank>Mobil gallery</a> - fotky z mobilu</vtipy><Br>&nbsp</TD>
			</TR>
			</TABLE>
			<BR>
			<?endif?>
			
	</Td>
	</Tr>
     </Table>
	 <!-- <BR><Center><a href="http://rumbler.wz.cz/hlavni.html"><B>-BACK-</a></center> -->
  </Tr>
  </body>

</HTML>
