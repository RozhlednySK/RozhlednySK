<HTML>
<HEAD>
<TITLE>Registrace nicku </TITLE>
<link rel="stylesheet" href="reg.css" type="text/css">
</HEAD>

<BODY>
<CENTER><H1>Registrace nicku</H1>
<FORM ACTION="regscript.php" METHOD=POST>
<TABLE bgcolor="#999999" WIDTH=300 border = 5 bordercolor="black" frame="box" rules="none">
<TR><TD><B>Nick: <TD><INPUT CLASS="pole" TYPE="text"  NAME="nick" >
    </TR>   
<TR><TD><B>Heslo:<TD><INPUT CLASS="pole" TYPE="password"  NAME="heslo" >
    </TR> 
</TABLE>
<P><CENTER><INPUT TYPE=SUBMIT CLASS="tlacitko" VALUE="Registrovat">
</FORM>
<br><br>
<CENTER>
</BODY>
</HTML>
