// here we define global variable
var ajaxdestination="";

function getdata(what,where) { 
 try {
   xmlhttp = window.XMLHttpRequest?new XMLHttpRequest():
  		new ActiveXObject("Microsoft.XMLHTTP");
 }
 catch (e) {  }

 ajaxdestination=where;
 xmlhttp.onreadystatechange = triggered; 
 xmlhttp.open("GET", what);
 xmlhttp.send(null);
 return false;
}

function triggered() { 
  if (xmlhttp.readyState == 4) if (xmlhttp.status == 200) 
    document.getElementById(ajaxdestination).innerHTML =xmlhttp.responseText;
}



