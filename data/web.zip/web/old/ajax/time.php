<? 
echo date("H:i:s"); 
?>
