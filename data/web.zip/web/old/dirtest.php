<?
$dir = opendir("brnosession/mini");//List files in images directory
$i = 0;
$dir1 = DirName($PATH_TRANSLATED);
echo  $SERVER_NAME ."<BR>";
echo  $REMOTE_HOST ."<BR>"; 
echo DirName($PATH_TRANSLATED)	 . "<BR>";
echo  SubStr(DirName($PATH_TRANSLATED), StrRPos(DirName($PATH_TRANSLATED),"/") + 1,StrLen(DirName($PATH_TRANSLATED)) -StrRPos(DirName($PATH_TRANSLATED),"/") ). "<BR>";

while (($file = readdir($dir)) != false)
  {
  echo "filename: " . $file . "<br />";
  $i += 1;
  }closedir($dir);

echo "<BR>" . $i;


?>